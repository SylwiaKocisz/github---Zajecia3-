var newdiv = document.createElement("div");
newdiv.textContent = "A new element!?!";
document.body.appendChild(newdiv);