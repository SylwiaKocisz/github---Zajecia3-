# devops-debug

## 1. Przygotowania
1. Sprawdź, czy masz zainstalowane Visual Studio Code. Jezeli nie, zainstaluj VSC ze strony https://code.visualstudio.com/
2. Sprawdź, czy masz zainstalowany Chrome. Jeeli nie, zainstaluj go ze strony https://www.google.com/intl/pl_ALL/chrome/

## 2. Zadania
1. Zdebugować i poprawić stronę w folderze HTML
2. Zdebugować i poprawić kod JS strony w folderze JS

## Linki
1. Kurs devtools - https://developers.google.com/web/tools/chrome-devtools/
2. Frontend developer handbook 2019 - https://frontendmasters.com/books/front-end-handbook/2019/
3. Vue CLI - https://cli.vuejs.org/
4. Kurs Vue - https://www.youtube.com/watch?v=4deVCNJq3qc
